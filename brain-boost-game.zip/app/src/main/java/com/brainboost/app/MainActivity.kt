package com.brainboost.app

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * The game itself is the HTML file in app/src/main/assets/index.html (runs inside a WebView).
 * Only the rewarded video ad is native. JS calls Android.showRewarded(); we answer with
 * onRewardEarned() / onRewardCancelled() / onAdNotReady() inside the page.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var rewardedAd: RewardedAd? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true   // coins are saved in localStorage
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        MobileAds.initialize(this) { loadAd() }
    }

    private fun loadAd() {
        RewardedAd.load(this, BuildConfig.REWARDED_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
                override fun onAdFailedToLoad(e: LoadAdError) { rewardedAd = null }
            })
    }

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }

    private fun showRewarded() {
        val ad = rewardedAd
        if (ad == null) { js("onAdNotReady()"); loadAd(); return }
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null; loadAd()
                js(if (earned) "onRewardEarned()" else "onRewardCancelled()")
            }
            override fun onAdFailedToShowFullScreenContent(e: AdError) {
                rewardedAd = null; loadAd(); js("onAdNotReady()")
            }
        }
        ad.show(this) { earned = true }
    }

    inner class Bridge {
        @JavascriptInterface
        fun showRewarded() { runOnUiThread { this@MainActivity.showRewarded() } }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.goBack ? goBack() : false)") { r -> if (r != "true") finish() }
    }
}
