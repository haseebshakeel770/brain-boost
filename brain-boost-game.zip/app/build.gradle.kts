plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ===== AD SETTINGS =====
// true  = Google TEST ads (safe, no earnings). Use this while testing.
// false = your REAL ads. Change to false only for the final version.
val useTestAds = true

val testAppId = "ca-app-pub-3940256099942544~3347511713"
val testRewardedId = "ca-app-pub-3940256099942544/5224354917"
val realAppId = "ca-app-pub-8610904151017465~3113800725"
val realRewardedId = "ca-app-pub-8610904151017465/7615172577"

android {
    namespace = "com.brainboost.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.brainboost.app"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "REWARDED_UNIT_ID", "\"" + (if (useTestAds) testRewardedId else realRewardedId) + "\"")
        manifestPlaceholders["admobAppId"] = if (useTestAds) testAppId else realAppId
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:23.2.0")
}
